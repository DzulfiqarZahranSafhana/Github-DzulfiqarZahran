/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dzulfiqar Zahran S
 */
public class SI_Billing {
    private int id_si_billing;
    private String nama_pasien;
    private int biaya_perawatan;
    private String obat;
    private int total_biaya;

    public SI_Billing() {
    }

    public SI_Billing(int id_si_billing, String nama_pasien, int biaya_perawatan, String obat, int total_biaya) {
        this.id_si_billing = id_si_billing;
        this.nama_pasien = nama_pasien;
        this.biaya_perawatan = biaya_perawatan;
        this.obat = obat;
        this.total_biaya = total_biaya;
    }

    public int getId_si_billing() {
        return id_si_billing;
    }

    public void setId_si_billing(int id_si_billing) {
        this.id_si_billing = id_si_billing;
    }

    public String getNama_pasien() {
        return nama_pasien;
    }

    public void setNama_pasien(String nama_pasien) {
        this.nama_pasien = nama_pasien;
    }

    public int getBiaya_perawatan() {
        return biaya_perawatan;
    }

    public void setBiaya_perawatan(int biaya_perawatan) {
        this.biaya_perawatan = biaya_perawatan;
    }

    public String getObat() {
        return obat;
    }

    public void setObat(String obat) {
        this.obat = obat;
    }

    public int getTotal_biaya() {
        return total_biaya;
    }

    public void setTotal_biaya(int total_biaya) {
        this.total_biaya = total_biaya;
    }

    @Override
    public String toString() {
        return "SI_Billing{" + "id_si_billing=" + id_si_billing + ", "
                + "nama_pasien=" + nama_pasien + ", "
                + "biaya_perawatan=" + biaya_perawatan + ", "
                + "obat=" + obat + ", "
                + "total_biaya=" + total_biaya + '}';
    }
}
