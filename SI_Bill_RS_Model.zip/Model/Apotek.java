/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dzulfiqar Zahran S
 */
public class Apotek {
    private int id_apotek;

    public Apotek() {
    }

    public Apotek(int id_apotek) {
        this.id_apotek = id_apotek;
    }

    public int getId_apotek() {
        return id_apotek;
    }

    public void setId_apotek(int id_apotek) {
        this.id_apotek = id_apotek;
    }

    @Override
    public String toString() {
        return "Apotek{" + "id_apotek=" + id_apotek + '}';
    }
    
    
}
