/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dzulfiqar Zahran S
 */
public class UGD {
    private int UGD;

    public UGD() {
    }

    public UGD(int UGD) {
        this.UGD = UGD;
    }

    public int getUGD() {
        return UGD;
    }

    public void setUGD(int UGD) {
        this.UGD = UGD;
    }

    @Override
    public String toString() {
        return "UGD{" + "UGD=" + UGD + '}';
    }
    
    
}
