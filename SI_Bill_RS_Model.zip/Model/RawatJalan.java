/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dzulfiqar Zahran S
 */
public class RawatJalan {
    private int id_rawatjalan;

    public RawatJalan() {
    }

    public RawatJalan(int id_rawatjalan) {
        this.id_rawatjalan = id_rawatjalan;
    }

    public int getId_rawatjalan() {
        return id_rawatjalan;
    }

    public void setId_rawatjalan(int id_rawatjalan) {
        this.id_rawatjalan = id_rawatjalan;
    }

    @Override
    public String toString() {
        return "RawatJalan{" + "id_rawatjalan=" + id_rawatjalan + '}';
    }
    
}
